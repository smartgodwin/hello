@extends('mylayouts.app')

@section('titre')
    page17
@endsection

@section('main')
    <section class="section_page17">
        <div class="container_page17">
            <div class="img_page17"><img src="{{ asset('frontend/image/image_adress.jpg') }}" alt=""></div>
            <div class="icone_page17"><img src="{{ asset('frontend/icons/Icone add photo.png') }}" alt=""></div>
        </div>

    </section>
@endsection
