<?php $__env->startSection('titre'); ?>
   <?php echo e(__(' validation')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>

<section class="section_page9">
    <div class="page9_container">
        <h3 class="mb-3"><?php echo e(__('Adresse ajoutée !')); ?></h3>
        <span class="text-success fs-3"><i class="fa-regular fa-circle-check"></i></span>
        <p class="mb-3"><?php echo e(__('Votre adresse a été enregistrer')); ?> <br><?php echo e(__('verifiez mes adresses')); ?> <br><?php echo e(__('pour le voir')); ?></p>
        <a href="<?php echo e(route('address.search')); ?>"><button>OK</button></a>
    </div>
</section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('mylayouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mlaga\Desktop\Projet\Sunofa-Map\resources\views/pages/validation.blade.php ENDPATH**/ ?>