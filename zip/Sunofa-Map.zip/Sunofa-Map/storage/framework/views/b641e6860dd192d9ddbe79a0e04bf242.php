<?php $__env->startSection('titre'); ?>
    <?php echo e(__('notification')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
 
    <section class="section_page12">

        <div class="page12_container">

            <?php if(Auth::check() && Auth::user()->notifications->count() > 0): ?>
                <?php $__currentLoopData = Auth::user()->notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="page12_notif">
                        <p class="m-0"><?php echo e($notification->created_at->format('d/m/Y H:i')); ?></p>

                        <?php if($notification->data['type'] == 'pin_request'): ?>
                            <div class="page12_message rounded">
                                <p>
                                    <?php echo e(__('Une demande de code PIN a été faite pour votre adresse')); ?> :
                                    <?php echo e($notification->data['address']['adressName']); ?><br>
                                    Par : <?php echo e($notification->data['reciver']['name'] ?? 'Inconnu'); ?><br>
                                    
                                    <?php echo e(__('Son mail est')); ?> :
                                    <?php if($notification->data['reciver']['email']): ?>
                                        <a href="mailto:<?php echo e($notification->data['reciver']['email']); ?>"><?php echo e($notification->data['reciver']['email']); ?></a>
                                    <?php else: ?>
                                        <?php echo e(__('Inconnu')); ?>

                                    <?php endif; ?>
                                    <br>

                                    <?php echo e(__('Son numéro de téléphone ')); ?>:
                                    <?php if($notification->data['reciver']['phone_number']): ?>
                                        <a href="tel:<?php echo e($notification->data['reciver']['phone_number']); ?>"><?php echo e($notification->data['reciver']['phone_number']); ?></a>
                                    <?php else: ?>
                                        <?php echo e(__('Inconnu')); ?>

                                    <?php endif; ?>
                                    <br>
                                </p>
                                <hr>

                                <form action="<?php echo e(route('notifications.sendCodePin', $notification->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-link link-underline-opacity-0 link-success"
                                        style="border: none;font-size: 20px; background: transparent;"
                                        <?php echo e($notification->data['code_sent'] ?? false ? 'disabled' : ''); ?>>
                                        <span class="me-3"><i
                                                class="fa-solid fa-share-from-square"></i></span><?php echo e($notification->data['code_sent'] ?? false ? 'Code envoyé' : 'Envoyer le code'); ?>

                                    </button>
                                </form>
                            </div>

                            <div class="d-flex justify-content-between">
                                <form class="w-30" action="<?php echo e(route('notifications.markasread', $notification->id)); ?>"
                                    method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>
                                    <button type="submit" class="btn btn-link link-underline-opacity-0 link-secondary"
                                        style="cursor: pointer;">

                                        <?php if($notification->read_at): ?>
                                            <span><i class="fa-solid fa-check-double link-primary me-2"></i><?php echo e(__('lu')); ?></span>
                                        <?php else: ?>
                                            <span><i class="fa-solid fa-check-double link-secondary me-2"></i><?php echo e(__('lire')); ?></span>
                                        <?php endif; ?>
                                    </button>
                                </form>
                                <form class="w-30" action="<?php echo e(route('notifications.destroy', $notification->id)); ?>"
                                    method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-link link-underline-opacity-0 link-danger"
                                        style="cursor: pointer; color:red;"><span><i class="fa-solid fa-trash"></i></span>
                                       <?php echo e(__('supprimer')); ?></button>
                                </form>
                            </div>
                        <?php elseif($notification->data['type'] == 'pin_sent'): ?>
                            <p class="page12_message rounded">
                                <?php echo e(__('Le code PIN pour l\'adresse')); ?> : <?php echo e($notification->data['address']['adressName']); ?> <?php echo e(__('a été envoyé')); ?>.<br>
                                <?php echo e(__('Voici le code pin')); ?> : <span
                                    class="fs-3 fw-bold"><?php echo e($notification->data['codePin']); ?></span><br>
                                <a href="<?php echo e(route('address.show', ['id' => $notification->data['address']['id']])); ?>"><?php echo e(__('aller sur l\'address')); ?></a>
                            </p>
                            <div class="d-flex justify-content-between align-items-center">
                                <form action="<?php echo e(route('notifications.markasread', $notification->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>
                                    <button type="submit" class="btn btn-link link-underline-opacity-0 link-secondary"
                                        style="cursor: pointer;">

                                        <?php if($notification->read_at): ?>
                                            <span class="link-primary"><i
                                                    class="fa-solid fa-check-double me-2"></i><?php echo e(__('Lu')); ?></span>
                                        <?php else: ?>
                                            <span><i class="fa-solid fa-check-double me-2"></i><?php echo e(__('lire')); ?></span>
                                        <?php endif; ?>
                                    </button>
                                </form>
                                <form action="<?php echo e(route('notifications.destroy', $notification->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-link link-underline-opacity-0 link-danger"
                                        style="cursor: pointer;"><span><i class="fa-solid fa-trash"></i></span>
                                        <?php echo e(__('supprimer')); ?></button>
                                </form>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <h3 class="text-secondary text-center"><?php echo e(__('vous n\'avez auccune de notification')); ?></h3>
            <?php endif; ?>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('mylayouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mlaga\Desktop\Projet\Sunofa-Map\resources\views/pages/notification.blade.php ENDPATH**/ ?>