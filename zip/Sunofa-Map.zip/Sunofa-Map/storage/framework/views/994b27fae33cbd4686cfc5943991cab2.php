
<div class="sid_bar">
    <div class="offcanvas offcanvas-start" data-bs-scroll="true" tabindex="-1" id="offcanvasWithBothOptions" aria-labelledby="offcanvasWithBothOptionsLabel">
    <div class="offcanvas-header">
        <h5 class="offcanvas-title" id="offcanvasWithBothOptionsLabel">Sunofa Map</h5>
        <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <hr>
    <div class="offcanvas-body">
        <div class="side_add">
            <div class="ad_btn w-100">
                <a href="/address"><?php echo e(__('ajouter')); ?> <span><i class="ps-3 fa-solid fa-plus"></i></span></a>
            </div>
        </div>

        <hr>

        <div class="container mt-4" style="overflow-y: scroll; margin-bottom: 20px; padding-bottom:20px;">
            <div class="side_contener">
                <div class="side_option">
                    <a class="text-decoration-none" href="/"><h5><span class="me-3"><i class="fa-solid fa-house"></i></span><?php echo e(__('Accueil')); ?></h5></a>
                </div>
                <div class="side_option">
                    <a class="text-decoration-none" href="/search"><h5><span class="me-3"><i class="fa-solid fa-magnifying-glass-location"></i></span><?php echo e(__('Rechercher')); ?></h5></a>
                </div>
                <div class="side_option">
                    <a class="text-decoration-none" href="/info"><h5><span class="me-3"><i class="fa-regular fa-circle-question"></i></span><?php echo e(__('A propos')); ?></h5></a>
                </div>
                <div class="side_option disable">
                    
                    <a class="text-decoration-none" href="/favories"><h5><span class="me-3"><i class="fa-solid fa-book"></i></span><?php echo e(__('Carnet d\'adresses')); ?></h5></a>
                </div>
                <div class="side_option">
                    <?php if(auth()->guard()->check()): ?>
                    
                    <a class="text-decoration-none" href="<?php echo e(route('user.addresses',Auth::user()->id)); ?>"><h5><span class="me-3"><i class="fa-solid fa-map-location-dot"></i></span> <?php echo e(__('Mes adresses')); ?></h5></a>
                    
                    <?php endif; ?>
                </div>
                <div class="side_option hn">
                    <?php if(auth()->guard()->check()): ?>
                       <a class="text-decoration-none" href="/notification"><h5><span class="me-3"><i class="fa-solid fa-bell"></i></span><?php echo e(__('Notification')); ?>

                        <?php if(Auth::check()): ?>
                        <?php
                            $unreadCount = Auth::user()->unreadNotifications->count();
                        ?>
                        <?php if($unreadCount > 0): ?>
                            <span class="badge bg-danger ms-2" style="
                            z-index: 2;
                            height: fit-content;
                            position: absolute;
                        "><?php echo e($unreadCount); ?></span>
                        <?php endif; ?>
                    <?php endif; ?>
                    </h5></a>                 
                    <?php endif; ?>
                </div>
                
                <div class="side_option">
                    <h4 class="d-flex align-items-center"><span class="me-3"><i class="fa-solid fa-language"></i></span>
                        <div class="btn-group">
                            <button class="btn lang dropdown-toggle" type="button" data-bs-toggle="dropdown" data-bs-auto-close="true" aria-expanded="false">
                            <?php echo e(__('langue')); ?>

                            </button>
                            <ul class="dropdown-menu">
                            <li><a class="dropdown-item option" href="/locale/fr"><?php echo e(__('français')); ?></a></li>
                            <li><a class="dropdown-item option" href="/locale/en"><?php echo e(__('anglais')); ?></a></li>
                            <li><a class="dropdown-item option" href="/locale/es"><?php echo e(__('espagnole')); ?></a></li>
                            </ul>
                        </div>
                    </h4>
                </div>
                <?php if(Auth::user() && Auth::user()->hasAnyRole(['Admin', 'SuperAdmin'])): ?>
                    
                    <div class="side_option">
                        <?php if(auth()->guard()->check()): ?>
                        
                            <a class="text-decoration-none" href="<?php echo e(route('dashboard')); ?>"><h5><span class="me-3"><i class="fa-solid fa-table-columns"></i></span> <?php echo e(__('Tableau de bord')); ?></h5></a>
                        
                        <?php endif; ?>
                    </div>

                <?php endif; ?>
                

                <!-- Menu déroulant Bootstrap -->
                <div class="dropdown profile d-flex justify-content-start align-items-center bg-white">

                    <span class="d-flex justify-content-center align-items-center me-2" style="width: 39px; height: 39px; font-size: 20px"><i class="fa-regular fa-user"></i></span>
                    <?php if(auth()->guard()->check()): ?>
                        <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false">
                            <?php echo e(Auth::user()->name); ?>

                        </button>
                        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                            <li>
                                <a class="dropdown-item" href="<?php echo e(route('profile.index', ['id' => Auth::user()->id])); ?>">
                                    <?php echo e(__('Profile')); ?>

                                </a>
                            </li>
                            <li>
                                <form method="POST" action="<?php echo e(route('logout')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <button class="dropdown-item" type="submit">
                                        <?php echo e(__('Se déconnecter')); ?>

                                    </button>
                                </form>
                            </li>
                        </ul>
                    <?php endif; ?>
                    <?php if(auth()->guard()->guest()): ?>
                        <a href="<?php echo e(route('login')); ?>" style="font-size: 20px" class="btn"><?php echo e(__('Se connecter')); ?></a>
                    <?php endif; ?>
                </div>

            </div>
        </div>
        </div>
    </div>
    </div>
</div>

<nav>
   <div class="menu">
        <h2 class="p-0 m-0"><span data-bs-toggle="offcanvas" data-bs-target="#offcanvasWithBothOptions" aria-controls="offcanvasWithBothOptions"><i class="pe-3 fa-solid fa-bars"></i></span> <a href="/" style="color: #ffff; text-decoration: none;">Sunofa Map</a></h2>
    </div>

    <div class="notif">
        <p class="m-0 p-0" style="width: 39px; height: 39px">
           
            <a href="/notification">
                <span  style="
                display: flex;
                position: relative;
                width: 100%;
                ">
                    <img class="w-100" src="<?php echo e(asset('frontend/icons/icone-notification2.png')); ?>" alt="">
                    <?php if(Auth::check()): ?>
                        <?php
                            $unreadCount = Auth::user()->unreadNotifications->count();
                        ?>
                        <?php if($unreadCount > 0): ?>
                            <span class="badge bg-danger" style="
                            z-index: 2;
                            height: fit-content;
                            position: absolute;
                            right: 0;
                        "><?php echo e($unreadCount); ?></span>
                        <?php endif; ?>
                    <?php endif; ?>
                </span>
            </a>
            
        </p>
        <p class="m-0 p-0 ms-5" style="width: 39px; height: 39px"><a href="/info"><span ><img class="w-100" src="<?php echo e(asset('frontend/icons/icone-info.png')); ?>" alt=""></span></a></p>
        
        <div class="btn-group ms-5">
            <button class="btn lang dropdown-toggle" type="button" data-bs-toggle="dropdown" data-bs-auto-close="true" aria-expanded="false">
             langue
            </button>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item option" href="/locale/fr"><?php echo e(__('français')); ?></a></li>
              <li><a class="dropdown-item option" href="/locale/en"><?php echo e(__('anglais')); ?></a></li>
              <li><a class="dropdown-item option" href="/locale/es"><?php echo e(__('espagnole')); ?></a></li>
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH C:\Users\mlaga\Desktop\Projet\Sunofa-Map\resources\views/mylayouts/nav.blade.php ENDPATH**/ ?>