<?php $__env->startSection('titre'); ?>
    <?php echo e(__('recherche')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
    <section class="section_page2">
        <div class="head_page2">
            <div class="head">
                <div class="ad_btn">
                    <a href="/address"><?php echo e(__('ajouter')); ?> <span><i class="ps-3 fa-solid fa-plus"></i></span></a>
                </div>
                <form method="POST" action="<?php echo e(route('address.doSearch')); ?>" style="width: 100%">
                    <?php echo csrf_field(); ?>
                    <div class="search">
                        <input type="search" name="pseudo" id="search" placeholder="search...">
                        <button type="submit"><span><i class="fa-solid fa-magnifying-glass"></i></span></button>
                    </div>
                </form>
            </div>
        </div>

        <?php if(isset($addresses) && $addresses): ?>
            <div class="page4_contener">
                <?php $__currentLoopData = $addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="seach_result mb-3">
                        <div class="result_img">
                            <?php if(isset($address->media) && $address->media->photo1): ?>
                                <img src="<?php echo e(asset($address->media->photo1)); ?>" alt="Address Image">
                            <?php else: ?>
                                <img src="<?php echo e(asset('frontend/image/maison.jpg')); ?>" alt="Default Image">
                            <?php endif; ?>
                        </div>
                        <div class="resut_descrip">
                            <div class="result_info">
                                <h3 class="m-0">Adresse de <?php echo e($address->user->name); ?></h3>
                                <p class="m-0"><?php echo e($address->adressName); ?></p>
                            </div>

                            <div class="resut_btn d-flex justify-content-between align-items-center" style="width: 20%">
                                <!-- Formulaire pour ajouter aux favoris -->
                                <form id="add-favorie-form-<?php echo e($address->id); ?>" action="<?php echo e(route('favories.store')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="address_id" value="<?php echo e($address->id); ?>">
                                    <button type="button" class="btn" onclick="addFavorie(<?php echo e($address->id); ?>)" style="background: none; border: none;">
                                        <span class="text-secondary">
                                            <i class="fa-solid fa-bookmark <?php echo e($address->isFavorited ? 'text-primary' : 'text-muted'); ?>"></i>
                                        </span>
                                    </button>
                                </form>

                                <!-- Vérification du code PIN si nécessaire -->
                                <?php if($address->codePin != null): ?>
                                    <!-- Bouton pour ouvrir le modal -->
                                    <button type="button" class="btn btn-v" data-bs-target="#exampleModalToggle"
                                    data-bs-toggle="modal">
                                        <?php echo e(__('afficher')); ?>

                                    </button>
                                <?php else: ?>
                                    <a class="btn btn-v" href="<?php echo e(route('address.show', $address->id)); ?>"><?php echo e(__('afficher')); ?></a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <!-- Modal pour vérifier le code PIN -->
                    
                    <div class="modal fade" id="exampleModalToggle" aria-hidden="true" aria-labelledby="exampleModalToggleLabel"
                            tabindex="-1">
                            <div class="modal-dialog modal-dialog-centered">
                                <div class="modal-content modal_contener">
                                    

                                    <div class="modal-body moda_body">
                                        <?php echo e(__('Cette adresse est privée,')); ?>

                                    <?php echo e(__(' saisissez le code pin ou envoyez une demande d\'accès')); ?>

                                    </div>
                                    <?php if(isset($address) && $address): ?>
                                        <div class="modal-footer modal_btn">
                                            <button class="btn btn-v" data-bs-target="#exampleModalToggle2" data-bs-toggle="modal"><?php echo e(__('j\'ai le code pin')); ?></button>
                                            <form class="w-100 display-contents" method="POST"
                                                action="<?php echo e(route('address.requestPin', $address->id)); ?>">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="btn-o"><?php echo e(__('demander un pin')); ?></button>
                                            </form>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                    </div>
                    <div class="modal fade" id="exampleModalToggle2" aria-hidden="true" aria-labelledby="exampleModalToggleLabel2"
                        tabindex="-1">
                        <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content modal_contener">

                                <?php if(session('error')): ?>
                                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                        <?php echo e(session('error')); ?>

                                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                    </div>
                                <?php endif; ?>
                                <?php if(session('status')): ?>
                                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                                        <?php echo e(session('status')); ?>

                                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                    </div>
                                <?php endif; ?>
                                <?php if(isset($address) && $address): ?>
                                    <form class="w-100" action="<?php echo e(route('address.validatePin', $address->id)); ?>" method="post">
                                        <div class="modal-body moda_body">
                                            <div class="pin_form">
                                                <div class="pin_form">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="number" name="full_pin" id="full_pin"  >
                                                </div>
                                            </div>
                                            <div class="modal-footer modal_btn">
                                                <button class="btn btn-v" data-bs-target="#exampleModalToggle"
                                                    data-bs-toggle="modal">retour</button>
                                                <button type="submit" class=" btn-o"><?php echo e(__('valider')); ?></button>
                                            </div>
                                        </div>
                                    </form>
                                <?php endif; ?>
                            </div>

                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php else: ?>
            <div class="page3_message">
                <?php if(session('error')): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php echo e(session('error')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                <?php if(session('status')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo e(session('status')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </section>

    <script>
        // Fonction pour ajouter l'adresse aux favoris
        function addFavorie(addressId) {
            let form = document.getElementById('add-favorie-form-' + addressId);
            let formData = new FormData(form);

            fetch(form.action, {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                },
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Changer la couleur de l'icône de favori
                    let bookmarkIcon = form.querySelector('i.fa-bookmark');
                    bookmarkIcon.classList.remove('text-muted');
                    bookmarkIcon.classList.add('text-primary');
                    alert('Adresse ajoutée aux favoris avec succès!');
                } else {
                    alert('Échec de l\'ajout de l\'adresse aux favoris.');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Une erreur est survenue.');
            });
        }

        // Fonction pour valider le code PIN via AJAX
        document.getElementById('pinForm').addEventListener('submit', function(event) {
            event.preventDefault();
            const pinInputs = document.querySelectorAll('input[name="pin[]"]');
            let fullPin = '';
            pinInputs.forEach(input => {
                fullPin += input.value;
            });
            document.getElementById('full_pin').value = fullPin;
            this.submit();
        });
    </script>
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('mylayouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mlaga\Desktop\Projet\Sunofa-Map\resources\views/pages/seach.blade.php ENDPATH**/ ?>