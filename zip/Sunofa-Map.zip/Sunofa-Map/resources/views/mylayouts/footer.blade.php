<footer>
    <p>&copy; <span id="current-year"></span> SUNOFA. Tous droits réservés.</p>
</footer>
